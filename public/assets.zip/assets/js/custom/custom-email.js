/*
-----------------------------
    : Custom - Email js :
-----------------------------
*/
"use strict";
$(document).ready(function() {
    /* -----  Email - Summernote ----- */
    $('.summernote').summernote({
        height: 200,
        minHeight: null,
        maxHeight: null,
        focus: true 
    });
});